<?php

echo <<< READ





READ;


?>