<?php
include "admin_header.php";
?>

<!--Main layout-->
<style>
  main{
    margin: 100px 10px 0px 16rem;

  }
  input[type=text]{
    width:25rem;

  }
  input[type=textarea]{
    width:35rem;
    height:15rem;

  }

</style>
<main >
  <div class="container pt-4">



  </div>
</main>
<!--Main layout-->
<?php
include "admin_footer.php";
?>