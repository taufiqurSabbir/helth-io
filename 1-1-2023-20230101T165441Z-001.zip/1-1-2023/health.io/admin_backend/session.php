<?php
session_start();
include "../db_connect.php";
$User_name=$_SESSION['user_name'];
$User_email=$_SESSION['email'];

?>