<?php
echo <<< READ

                <!-- MENU SECTION STARTS-->
                <section id="navbar">
                        <div class="container">
                            <nav>
                                <div class="row">
                                    <div class="col-10">
                                        <div class="leftpart">
                                            <div class="logo">
                                                <a href="Homepage.html"><img src="images/logo.png" alt="file not found"></a>
                                            </div>

                                            <div class="link">
                                                <ul>
                                                    <li><a href="Student_dashboard.html">Dashboard</a> </li>
                                                    <li><a href="Pharmacy.html">Pharmacy</a> </li>
                                                    <li><a href="Doctor_appointment.html">Consultancy</a></li>
                                                    <li><a href="Blood_request.html">Blood Request</a></li>
                                                    <li><a href="Blood_request.html">My Posts</a></li>



                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="rightpart">
                                            <!-- Example single danger button -->
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-success dropdown-toggle" style="padding: 0rem 1rem"
                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                    <img src="images/settings.png" alt="" style="display: inline-block; width:1rem; ">
                                                    Edit
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li><a class="dropdown-item" href="#">Edit Profile</a></li>
                                                    <li><a class="dropdown-item" href="#">Settings </a></li>
                                                    <li>
                                                        <hr class="dropdown-divider">
                                                    </li>
                                                    <li><a class="dropdown-item" href="#">LOGOUT</a></li>
                                                </ul>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </section>
                    <!-- MENU SECTION ENDS -->

    READ;
    ?>